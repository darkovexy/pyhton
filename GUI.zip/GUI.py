
#Gui start............
from tkinter import *
from PIL import ImageTk, Image
from tkinter import filedialog as fd

root = Tk()
root.geometry("1200x720")
root.title("PixelMod")


def browse_file():
    name = fd.askopenfilename()
    image = Image.open(name)
    image = image.resize((200, 200), Image.ANTIALIAS)
    photo = ImageTk.PhotoImage(image)
    Label(topframe, image=photo).pack()
    print(name)
    
mainframe = Frame(root)
mainframe.pack(fill=BOTH,expand=True)

leftframe = Frame(mainframe,bg="yellow",border=5,width=300,height=10)
leftframe.pack(side=LEFT,fill=Y)
topframe = Frame(mainframe,border=5,height=360)
topframe.pack(side=TOP,fill=X)
bottomframe = Frame(mainframe,bg="blue",border=5,height=360)
bottomframe.pack(side=BOTTOM,fill=X)

lable = Label(topframe,text="Input image",fg="red")
lable.pack()
#for image
image = Image.open("1.jpg")
image = image.resize((200, 200), Image.ANTIALIAS)
photo = ImageTk.PhotoImage(image)
Label(topframe, image=photo).pack()
browse_button = Button(leftframe,text="Select your file", command=browse_file)
browse_button.pack(ipadx=20,ipady=20)





root.mainloop()
